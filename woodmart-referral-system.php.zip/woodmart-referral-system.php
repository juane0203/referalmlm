<?php
/**
 * Plugin Name:       Referral System Elextor
 * Description:       Sistema de referidos con árbol genealógico para WordPress y WooCommerce.
 * Version:           1.1.0
 * Author:            Juan Esteban Lugo Rodriguez
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       woodmart-referral-system
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to: 8.7 
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definir constantes del plugin
if ( ! defined( 'WRS_PLUGIN_VERSION' ) ) {
    define( 'WRS_PLUGIN_VERSION', '1.1.0' );
}
if ( ! defined( 'WRS_PLUGIN_DIR_PATH' ) ) {
    define( 'WRS_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'WRS_PLUGIN_DIR_URL' ) ) {
    define( 'WRS_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'WRS_PLUGIN_FILE' ) ) {
    define( 'WRS_PLUGIN_FILE', __FILE__ );
}

// Cargar archivos de inclusión del plugin
// -------------------------------------------------------------------------

// Para prevenir el auto-login
add_filter( 'woocommerce_registration_auth_new_customer', 'wrs_prevent_autologin_after_registration', 10, 1 );

add_filter( 'woocommerce_registration_redirect', 'wrs_custom_registration_redirect', 99 );
add_action( 'woocommerce_created_customer', 'wrs_send_custom_welcome_email', 20, 2 );
// 1. Funciones Core y Helpers
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-core-functions.php';

// 2. Registro de Custom Post Types y Taxonomías
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-cpt-tax.php';

// 3. Definición de Shortcodes
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-shortcodes.php';

// 4. Manejadores AJAX
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-ajax-handlers.php';

// 5. Funcionalidad de Registro de Usuario (WooCommerce)
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-user-registration.php';

// 6. Funcionalidad de "Mi Cuenta" (WooCommerce)
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-user-account.php';

// 7. Lógica Central de Referidos (Genealogía, Captura de Referente/Iniciativa)
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-referral-logic.php';

// 8. Funcionalidad de Administración
require_once WRS_PLUGIN_DIR_PATH . 'includes/admin/wrs-admin-menu.php';
require_once WRS_PLUGIN_DIR_PATH . 'includes/admin/wrs-admin-network-page.php';
require_once WRS_PLUGIN_DIR_PATH . 'includes/admin/wrs-admin-user-profile.php';
require_once WRS_PLUGIN_DIR_PATH . 'includes/admin/wrs-admin-export.php';

// 9. Integraciones (Zoho CRM)
require_once WRS_PLUGIN_DIR_PATH . 'includes/integrations/wrs-zoho-integration.php';

// 10. Encolado de Scripts y Estilos
require_once WRS_PLUGIN_DIR_PATH . 'includes/wrs-enqueue-assets.php';
// Hooks para los endpoints de "Mi Cuenta"
add_filter( 'woocommerce_account_menu_items', 'wrs_add_account_menu_items', 20 ); // Prioridad 20 para que se añadan después de los de WC
add_action( 'init', 'wrs_add_account_endpoints' );
add_action( 'woocommerce_account_referral-links_endpoint', 'wrs_referral_links_endpoint_content' );
add_action( 'woocommerce_account_genealogy-tree_endpoint', 'wrs_genealogy_tree_endpoint_content' );
add_action( 'woocommerce_account_my-profile_endpoint', 'wrs_my_profile_endpoint_content' );

// Hooks para validar y guardar los datos del formulario "Mi Perfil WRS"
add_action( 'woocommerce_save_account_details_errors', 'wrs_validate_my_profile_details_on_save', 10, 2 );
add_action( 'woocommerce_save_account_details', 'wrs_save_my_profile_details_wrs_fields', 10, 1 );

// Registrar Hooks (acciones y filtros)
// -------------------------------------------------------------------------

// -- Hooks de Inicialización General --
add_action('init', 'wrs_start_session', 1); // De wrs-core-functions.php
add_action('init', 'wrs_register_initiatives_cpt'); // De wrs-cpt-tax.php (antes wrs_register_landing_page_cpt)
add_action('init', 'wrs_register_initiative_category_taxonomy', 0); // De wrs-cpt-tax.php
add_action('init', 'wrs_add_account_endpoints'); // De wrs-user-account.php
// La siguiente función se llamaba wrs_capture_and_store_referrer y wrs_capture_landing_page_session
// ahora combinada en wrs_capture_referrer_and_initiative_session
add_action('init', 'wrs_capture_referrer_and_initiative_session', 5); // De wrs-referral-logic.php (prioridad ajustada)
// add_action('template_redirect', 'wrs_capture_landing_page_session'); // Esta lógica está ahora en la de arriba.

// -- Hooks para el Formulario de Registro de WooCommerce --
add_action('woocommerce_register_form', 'wrs_add_custom_registration_fields', 20); // De wrs-user-registration.php
add_filter('woocommerce_registration_errors', 'wrs_validate_custom_registration_fields', 10, 3); // De wrs-user-registration.php
add_action('woocommerce_created_customer', 'wrs_save_custom_registration_fields', 10, 1); // De wrs-user-registration.php (prioridad 10 para que se ejecute antes que Zoho y el logout)

// -- Hooks para el Comportamiento Post-Registro (No Autologin, Mensaje) --
add_action('wp_loaded', 'wrs_prevent_autologin_after_registration', 5); // De wrs-user-registration.php
add_action('woocommerce_created_customer', 'wrs_registration_completed_actions', 90, 3); // De wrs-user-registration.php (prioridad tardía)

// -- Hooks para "Mi Cuenta" de WooCommerce --
add_filter('woocommerce_account_menu_items', 'wrs_add_account_menu_items', 20, 1); // De wrs-user-account.php
add_action('woocommerce_account_referral-links_endpoint', 'wrs_referral_links_endpoint_content'); // De wrs-user-account.php
add_action('woocommerce_account_genealogy-tree_endpoint', 'wrs_genealogy_tree_endpoint_content'); // De wrs-user-account.php
add_action('woocommerce_account_my-profile_endpoint', 'wrs_my_profile_endpoint_content'); // De wrs-user-account.php


// -- Hooks de Administración --
add_action('admin_menu', 'wrs_add_referral_network_admin_menu'); // De wrs-admin-menu.php
add_action('show_user_profile', 'wrs_display_custom_user_profile_section'); // De wrs-admin-user-profile.php
add_action('edit_user_profile', 'wrs_display_custom_user_profile_section'); // De wrs-admin-user-profile.php
add_action('personal_options_update', 'wrs_save_custom_user_profile_fields'); // De wrs-admin-user-profile.php
add_action('edit_user_profile_update', 'wrs_save_custom_user_profile_fields'); // De wrs-admin-user-profile.php
add_action('admin_action_export_wrs_network', 'wrs_handle_network_data_export'); // De wrs-admin-export.php

// -- Hooks para Encolar Scripts y Estilos --
// add_action('wp_enqueue_scripts', 'wrs_frontend_enqueue_assets'); // De wrs-enqueue-assets.php
add_action('admin_enqueue_scripts', 'wrs_admin_enqueue_assets'); // De wrs-enqueue-assets.php

// -- Hooks para Shortcodes --
add_shortcode( 'wrs_register_button', 'wrs_register_button_shortcode_handler' ); // De wrs-shortcodes.php

// -- Hooks para Manejadores AJAX --
add_action( 'wp_ajax_nopriv_wrs_get_municipios', 'wrs_ajax_get_municipios_handler' ); // De wrs-ajax-handlers.php
add_action( 'wp_ajax_wrs_get_municipios', 'wrs_ajax_get_municipios_handler' ); // De wrs-ajax-handlers.php

// -- Hook para la Plantilla de Iniciativas --
add_filter( 'template_include', 'wrs_include_initiative_template' ); // De wrs-cpt-tax.php

// -- Hooks de Activación/Desactivación --
// Estas funciones deben estar en este archivo principal o ser cargadas antes de registrar el hook.
// Por simplicidad y porque ya las tenías aquí, las dejamos, pero podrían ir a un archivo de "instalación".
/**
 * Acciones al activar el plugin.
 * Registra CPTs, Taxonomías, Endpoints y limpia las reglas de reescritura.
 */
function wrs_plugin_on_activate() {
    // Asegurar que las funciones de registro estén disponibles
    if (function_exists('wrs_register_initiatives_cpt')) {
        wrs_register_initiatives_cpt();
    }
    if (function_exists('wrs_register_initiative_category_taxonomy')) {
        wrs_register_initiative_category_taxonomy();
    }
    if (function_exists('wrs_add_account_endpoints')) {
        wrs_add_account_endpoints();
    }
    flush_rewrite_rules();
}
register_activation_hook( WRS_PLUGIN_FILE, 'wrs_plugin_on_activate' );

/**
 * Acciones al desactivar el plugin.
 * Limpia las reglas de reescritura.
 */
function wrs_plugin_on_deactivate() {
    // Opcional: Registrar CPTs/Tax/Endpoints antes de flushear puede ayudar en algunos casos.
    if (function_exists('wrs_register_initiatives_cpt')) {
        wrs_register_initiatives_cpt();
    }
    if (function_exists('wrs_register_initiative_category_taxonomy')) {
        wrs_register_initiative_category_taxonomy();
    }
    if (function_exists('wrs_add_account_endpoints')) {
        wrs_add_account_endpoints();
    }
    flush_rewrite_rules();
}
register_deactivation_hook( WRS_PLUGIN_FILE, 'wrs_plugin_on_deactivate' );

// Nota: La lógica para la integración con Zoho CRM (incluyendo su página de ajustes y el hook 'woocommerce_created_customer' 
// para wrs_send_user_data_to_zoho_crm) ya está dentro de 'includes/integrations/wrs-zoho-integration.php'
// y ese archivo ya se está cargando con require_once. Los hooks de Zoho se registran dentro de ese archivo.

// El hook para wrs_save_my_profile_details_action (actualización del perfil de Mi Cuenta WRS)
// también se añade dentro de 'includes/wrs-user-account.php' o se podría mover aquí.
// Por ahora, asumimos que está allí o lo gestionaremos centralizadamente si es necesario.
// Lo importante es que la función exista antes de que el hook sea añadido.

// La función wrs_handle_my_profile_update_on_template_redirect que usamos para el perfil
// se añade dentro de 'includes/wrs-user-account.php'.

function wrs_force_frontend_scripts_for_debug() {
    if ( function_exists('is_account_page') && is_account_page() && function_exists('is_wc_endpoint_url') && is_wc_endpoint_url( 'genealogy-tree' ) ) {
        
        $plugin_dir_url = WRS_PLUGIN_DIR_URL; 
        $plugin_version = WRS_PLUGIN_VERSION; 

        wp_enqueue_script('cytoscape-lib', 'https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.28.1/cytoscape.min.js', array(), '3.28.1', true );
        
        // Popper y cytoscape-popper ELIMINADOS
            
        wp_enqueue_script( 
            'wrs-cytoscape-custom-chart-frontend', 
            $plugin_dir_url . 'assets/js/wrs-cytoscape-chart.js',
            array('jquery', 'cytoscape-lib'), // Solo jQuery y Cytoscape Lib como deps
            $plugin_version . '_' . time(), true 
        );
        error_log('[WRS Frontend Enqueue - Tooltips Manuales] Scripts para frontend encolados.');
    }
}
add_action( 'wp_enqueue_scripts', 'wrs_force_frontend_scripts_for_debug', 9999 ); 
?>